def deltaLoad():
    return "tbd"