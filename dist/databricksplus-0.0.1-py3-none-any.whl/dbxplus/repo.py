def getCurrentBranch():
    return "dummy";